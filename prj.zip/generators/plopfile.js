/**
 * Plopfile generator: https://plopjs.com/
 */

module.exports = plop => {
  plop.load('./component-generator.js')
}
