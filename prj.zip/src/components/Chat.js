import React from 'react';
import './Chat.css';
export const Chat = ({ author, message }) => {
  const _HandleClose = () => {
    alert('Close Chat Panel');
  };
  const _SendMsg = () => {
    alert('msg sent');
  };
  return (
    <div className="card">
      <div className="header">
        <div className="avatar" style={{ backgroundImage: `url(${author.avatar})` }}></div>
        <div className="title">
          <span className="displayName">{author.displayName}</span>
          <span className="fonction">{author.displayName}</span>
        </div>
        <button onClick={_HandleClose} className="toggler">
          <img src={require('../assets/svg/close.svg')} />
        </button>
      </div>
      <div className="body">{message}</div>
      <div className="actions">
        <input type="text" placeholder="Type your message .." />
        <button onClick={_SendMsg}>Send</button>
      </div>
    </div>
  );
};
