import React from 'react';
import { withDesign } from 'storybook-addon-designs';
import { Bestsellers } from './Bestsellers';
import { Container } from './Container';
export default {
  title: 'Component/Bestsellers',
  component: Bestsellers,
  decorators: [withDesign],
  argTypes: {},

  parameters: {
    design: {
      type: 'image',
      url: 'https://res.cloudinary.com/elie-tech/image/upload/v1604444026/frontwork-prod/40:2.png',
    },
  },
};

const Story = (args) => (
  <Container>
    <Bestsellers {...args} />
  </Container>
);

export const Basic = Story.bind({});
Basic.args = {
  label: 'Bestsellers',
  items: [
    {
      _id: 1,
      image: require('../assets/images/item1.png'),
      slug: 'Nike Air Max 270',
      brand: 'Nike',
      price: 195.8,
    },
    {
      _id: 2,
      image: require('../assets/images/item2.png'),
      slug: 'Nike Air Max 90',
      brand: 'Nike',
      price: 195.8,
    },
    {
      _id: 3,
      image: require('../assets/images/item3.png'),
      slug: 'Nike Air Max Plus',
      brand: 'Nike',
      price: 195.8,
    },
  ],
};
