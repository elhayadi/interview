import React from 'react';
import './Bestsellers.css';
export const Bestsellers = ({ label, items }) => {
  return (
    <div className="Card">
      <div className="CardTitle">{label}</div>
      <div className="CardBody">
        {items.map((item) => (
          <div className="item" key={item._id}>
            <div className="thumbnail" style={{ backgroundImage: `url(${item.image})` }}></div>
            <div className="details">
              <div className="title">{item.slug}</div>
              <div className="brand">{item.brand}</div>
              <div className="price">{'$' + item.price}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
